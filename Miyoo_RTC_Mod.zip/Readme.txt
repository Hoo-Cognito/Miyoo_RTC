On Onion 4.3.0 with either MMP v3, (new 2024 batch device); or RTC mod on MM/MMP.

1. Paste zip to root of sd-card

2. Boot device with inserted sd-card

3. Navigate to Apps/ Tweaks/ System/ Date and time... Turn emulated time skip to -Off-

4. Then navigate to Apps/ clock... Set time. 

5. Enjoy